
# US Airline Sentiment Analysis (Streamlit)

A Streamlit web app for sentiment analysis on the Twitter US Airline Sentiment dataset.

## Project Structure
```
airline_sentiment_app/
├── app.py
├── data/
│   └── Tweets.csv
├── models/
│   ├── sentiment_pipeline.pkl
│   └── metrics.json
├── requirements.txt
└── README.md
```

## How to Run
1. Create & activate a virtual environment (recommended).
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Launch the app:
   ```bash
   streamlit run app.py
   ```

## Notes
- The model pipeline (TF-IDF + LinearSVC) is pre-trained and saved in `models/sentiment_pipeline.pkl`.
- A quick metric (`accuracy`) from a held-out split is stored in `models/metrics.json`.
