
import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import pickle
import re
from pathlib import Path

st.set_page_config(page_title="US Airline Sentiment - Streamlit", page_icon="✈️", layout="wide")

@st.cache_resource
def load_pipeline():
    with open(Path("models") / "sentiment_pipeline.pkl", "rb") as f:
        return pickle.load(f)

@st.cache_data
def load_data():
    df = pd.read_csv(Path("data") / "Tweets.csv")
    return df

def clean_text(s: str) -> str:
    s = s.lower()
    s = re.sub(r"http\S+|www\.\S+", " url ", s)
    s = re.sub(r"@\w+", " user ", s)
    s = re.sub(r"#", "", s)
    s = re.sub(r"[^a-z0-9\s]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s

st.title("✈️ Twitter US Airline Sentiment Analysis")
st.caption("Built with Streamlit • Dataset: Twitter US Airline Sentiment (Kaggle)")

df = load_data()
pipe = load_pipeline()

tab_home, tab_predict, tab_viz = st.tabs(["🏠 Home", "🔮 Sentiment Prediction", "📊 Visualization"])

with tab_home:
    st.header("Project Overview")
    st.write(
        '''
        **Objective:** Analyze and predict sentiment of tweets about US airlines.
        
        **Dataset:** Twitter US Airline Sentiment — contains labeled tweets (positive, neutral, negative).
        
        **Modules in this App**
        - **Home Module:** This page. Explains the project background and dataset.
        - **Sentiment Prediction Module:** Enter a tweet and get model prediction.
        - **Visualization Module:** Explore the dataset via Scatter, Box, Histogram, Line, and Bar charts.
        '''
    )
    st.subheader("Sample of the Data")
    st.dataframe(df[['airline', 'airline_sentiment', 'text']].head(10), use_container_width=True)

    st.subheader("Class Balance")
    counts = df['airline_sentiment'].value_counts().reset_index()
    counts.columns = ['sentiment','count']
    fig = px.bar(counts, x="sentiment", y="count", title="Sentiment Distribution")
    st.plotly_chart(fig, use_container_width=True)

with tab_predict:
    st.header("Predict Sentiment")
    st.write("Enter a tweet about a US airline and click **Predict**.")
    user_text = st.text_area("Tweet text", placeholder="e.g., 'My flight got delayed again. Super frustrated.'", height=120)
    if st.button("Predict"):
        if not user_text.strip():
            st.warning("Please enter some text.")
        else:
            cleaned = clean_text(user_text)
            pred = pipe.predict([cleaned])[0]
            st.success(f"**Predicted Sentiment:** {pred}")

with tab_viz:
    st.header("Explore the Dataset")
    st.write("Use the controls below to filter and visualize the data.")
    col1, col2, col3 = st.columns(3)
    with col1:
        airlines = ["All"] + sorted(list(df['airline'].dropna().unique()))
        sel_airline = st.selectbox("Airline", airlines)
    with col2:
        sentiments = ["All"] + sorted(list(df['airline_sentiment'].dropna().unique()))
        sel_sent = st.selectbox("Sentiment", sentiments)
    with col3:
        nrows = st.slider("Rows to sample", 100, min(5000, len(df)), 1000, step=100)

    dff = df.copy()
    if sel_airline != "All":
        dff = dff[dff['airline'] == sel_airline]
    if sel_sent != "All":
        dff = dff[dff['airline_sentiment'] == sel_sent]
    if len(dff) > nrows:
        dff = dff.sample(nrows, random_state=42)

    dff['tweet_length'] = dff['text'].astype(str).str.len()

    st.subheader("Scatter Plot")
    st.caption("Scatter of tweet length vs. (encoded) sentiment for a random sample.")
    sent_order = {s:i for i,s in enumerate(sorted(df['airline_sentiment'].unique()))}
    dff['sent_code'] = dff['airline_sentiment'].map(sent_order)
    fig_sc = px.scatter(dff, x="tweet_length", y="sent_code", color="airline_sentiment",
                        hover_data=["airline","text"], title="Tweet Length vs Sentiment")
    st.plotly_chart(fig_sc, use_container_width=True)

    st.subheader("Box Plot")
    fig_box = px.box(dff, x="airline_sentiment", y="tweet_length", points="all", title="Tweet Length by Sentiment")
    st.plotly_chart(fig_box, use_container_width=True)

    st.subheader("Histogram")
    fig_hist = px.histogram(dff, x="tweet_length", nbins=40, color="airline_sentiment", barmode="overlay",
                            title="Distribution of Tweet Length")
    st.plotly_chart(fig_hist, use_container_width=True)

    st.subheader("Line Plot")
    if 'tweet_created' in dff.columns:
        tmp = dff.copy()
        tmp['tweet_created'] = pd.to_datetime(tmp['tweet_created'], errors='coerce')
        ts = tmp.dropna(subset=['tweet_created']).set_index('tweet_created').resample('D').size().reset_index(name='count')
        fig_line = px.line(ts, x='tweet_created', y='count', title='Tweets Over Time (Daily)')
        st.plotly_chart(fig_line, use_container_width=True)
    else:
        st.info("No 'tweet_created' column available for time series plot in this dataset.")

    st.subheader("Bar Chart")
    by_airline = dff.groupby(['airline','airline_sentiment']).size().reset_index(name='count')
    fig_bar = px.bar(by_airline, x='airline', y='count', color='airline_sentiment', barmode='group',
                     title='Sentiment Counts per Airline')
    st.plotly_chart(fig_bar, use_container_width=True)

    st.subheader("Data Preview")
    st.dataframe(dff[['airline','airline_sentiment','text']].head(50), use_container_width=True)
